Chilean Accounting Chart and Tax Localization.
==============================================
Plan contable chileno e impuestos de acuerdo a disposiciones vigentes,
basado en plan de cuentas del Servicio de Impuestos Internos


Known issues / Roadmap
======================

Credits
=======
<p>
<img width="200" alt="Logo Konos" src="https://www.konos.cl/web/image/res.company/1/logo?unique=445cd30" />
</p>
**Konos** - http://konos.cl
 - Nelson Ramírez <info@konos.cl>

Contributors
------------

- Carlos Lopez Mite <celm1990@hotmail.com>
- Daniel Santibáñez Polanco <dsantibanez@globalresponse.cl>

